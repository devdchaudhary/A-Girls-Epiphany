//
//  Introduction.swift
//  A Girl's Epiphany
//
//  Created by Devanshu Dev Chaudhary on 09/04/22.
//

import Foundation
import SwiftUI

struct Introduction: View {
    
@State var Script = "Greetings, my friend! 🙋🏽‍♂️ Adolescence is a critical period in everyone's life as it is a time when our bodies are going through rapid physical and psychological changes and so our mind is in a very sensitive and impressionable phase. As a consequence what we experience when we're young impacts our behaviour as adults. Today I am going to tell you the story of a girl named Swana who has just recently moved to her new school is really looking forward to joining her new classmates. However things don't entirely go as she had hoped they would... Swana must go through all challenges thrown at her by not giving into her fears and must come out stronger than ever before. Drag Swana to her first lecture of the day - English and drop her there. There are 6 levels in total and every new level will take you to a new chapter in swana's life, so pay attention and follow all instructions closely. I hope by the end of this playground app to have taught you the importance of choosing your words carefully not just for others but also for yourself."
@State var Tip = "Please view the app in portrait mode for best experience."

var body: some View {
    
        NavigationView {
                    
        ZStack {
            
            Color(floorColor)
                .ignoresSafeArea()
            
        VStack(spacing: 50) {
        
            Text("A Girl's Epiphany")
                .font(.system(size: 40, weight: .heavy))
                .foregroundColor(.black)
                .shadow(radius: 10)
            
            Text(Script)
                .foregroundColor(.black)
                .font(.system(size: 15, weight: .medium))
                .padding()
            
            NavigationLink(destination: Prologue()) {
            Text("Start")
                .frame(width: 200, height: 59)
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(50)
                .shadow(radius: 10)
            }
            
            Text(Tip)
                .foregroundColor(.black)
                .font(.body)
                .padding()
            }
            .ignoresSafeArea()
            .statusBar(hidden: true)
          }
        }
        .navigationViewStyle(StackNavigationViewStyle())
        .navigationBarHidden(true)
        .navigationBarBackButtonHidden(true)
      }
}
