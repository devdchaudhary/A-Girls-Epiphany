//
//  Prologue.swift
//  A Girl's Epiphany
//
//  Created by Devanshu Dev Chaudhary on 07/04/22.
//

import SwiftUI
import SpriteKit
import AVKit

let floorColor = UIColor(red: 245/255.0, green: 245/255.0, blue: 220/255.0, alpha: 1.0)
let carpetColor = UIColor(red: 34.0/255.0, green: 139.0/255.0, blue: 34.0/255.0, alpha: 1.0)
let stuTableColor = UIColor(red: 222.0/255.0, green: 184.0/255.0, blue: 135.0/255.0, alpha: 1.0)

class MainHall: SKScene, ObservableObject {
               
    private var tapSoundEffect: AVAudioPlayer?
    private let swana = SKSpriteNode(imageNamed: "Swana_normal")
    private let floor = SKSpriteNode(color: floorColor, size: CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height))
    private let leftBoundary = SKSpriteNode(color: .brown, size: CGSize(width: 50, height: UIScreen.main.bounds.height))
    private let rightBoundary = SKSpriteNode(color: .brown, size: CGSize(width: 50, height: UIScreen.main.bounds.height))
    private let chair = SKSpriteNode(color: .black, size: CGSize(width: 50, height: 10))
    private let carpet = SKSpriteNode(color: carpetColor, size: CGSize(width: 100, height: 200))
    private let carpet2 = SKSpriteNode(color: carpetColor, size: CGSize(width: 100, height: 200))
    private let scienceClass = SKLabelNode(fontNamed:"Helvetica")
    private let englishClass = SKLabelNode(fontNamed:"Helvetica")
    private let fadeIn = SKAction.fadeIn(withDuration: 4)
    private let fadeOut = SKAction.fadeOut(withDuration: 4)
    @Published var Btnaction: Int = 0

    func squaredDistance(p1: CGPoint, p2: CGPoint) -> CGFloat {
        return pow(p2.x - p1.x, 2) + pow(p2.x - p1.x, 2)
    }

    override func didMove(to view: SKView) {
        physicsBody = SKPhysicsBody(edgeLoopFrom: frame)
        game()
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        tapSound()
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        for touch in touches {
            
            let location = touch.location(in: self)
            
            swana.position.x = location.x
            swana.position.y = location.y
                        
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        let nodesToDetect = [swana, carpet2]
        
        let squaredRadius: CGFloat = 25 * 25
        for _ in nodesToDetect {
            if squaredDistance(p1: swana.position, p2: carpet2.position) < squaredRadius {
                let scienceclassScene = ScienceScene(size: CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height))
                view?.presentScene(scienceclassScene)
                scene?.removeAllChildren()
                scene?.removeAllActions()
                Btnaction = 1
            }
        }
    }

    func tapSound() {
           
        let path = Bundle.main.path(forResource: "Tap Sound", ofType: "wav")!
        let url = URL(fileURLWithPath: path)
        
        do {
            
            tapSoundEffect = try AVAudioPlayer(contentsOf: url)
            
            tapSoundEffect?.play()
            
        }
            
        catch {
            
        }
    }
    
    func game() {

    swana.alpha = 1
    swana.position = CGPoint(x: frame.midX, y: frame.midY + 200)
    swana.size = CGSize(width: 75, height: 75)
    swana.zPosition = 2
    swana.physicsBody?.mass = 0
    swana.physicsBody = SKPhysicsBody(circleOfRadius: swana.size.width)
    swana.physicsBody?.affectedByGravity = false
    swana.physicsBody?.isDynamic = false
    swana.physicsBody?.allowsRotation = false
    addChild(swana)
                    
    carpet.alpha = 1
    carpet.position = CGPoint(x: frame.size.width / 3.15, y: 570)
    carpet.zPosition = 1
    carpet.physicsBody?.mass = 0
    carpet.physicsBody = SKPhysicsBody(rectangleOf: carpet.size)
    carpet.physicsBody?.affectedByGravity = false
    carpet.physicsBody?.isDynamic = false
    carpet.physicsBody?.allowsRotation = false
    addChild(carpet)
        
    carpet2.alpha = 1
    carpet2.position = CGPoint(x: frame.size.width / 1.45, y: 250)
    carpet2.zPosition = 1
    carpet2.physicsBody?.mass = 0
    carpet2.physicsBody = SKPhysicsBody(rectangleOf: carpet.size)
    carpet2.physicsBody?.affectedByGravity = false
    carpet2.physicsBody?.isDynamic = false
    carpet2.physicsBody?.allowsRotation = false
    addChild(carpet2)
        
    scienceClass.text = "SCIENCE"
    scienceClass.alpha = 1
    scienceClass.zPosition = 1
    scienceClass.fontSize = 18
    scienceClass.zRotation = .pi/2
    scienceClass.position = CGPoint(x: carpet.frame.midX, y: carpet.frame.midY)
    scienceClass.fontColor = .white
    scienceClass.physicsBody = SKPhysicsBody(circleOfRadius: 10.0)
    scienceClass.physicsBody?.affectedByGravity = false
    scienceClass.physicsBody?.isDynamic = false
    scienceClass.physicsBody?.allowsRotation = false
    addChild(scienceClass)
            
    englishClass.text =  "ENGLISH"
    englishClass.alpha = 1
    englishClass.zPosition = 1
    englishClass.zRotation = .pi*3/2
    englishClass.fontSize = 18
    englishClass.position = CGPoint(x: carpet2.frame.midX, y: carpet2.frame.midY)
    englishClass.fontColor = .white
    englishClass.physicsBody = SKPhysicsBody(circleOfRadius: 10.0)
    englishClass.physicsBody?.affectedByGravity = false
    englishClass.physicsBody?.isDynamic = false
    englishClass.physicsBody?.allowsRotation = false
    addChild(englishClass)
        
    floor.alpha = 1
    floor.position = CGPoint(x: frame.size.width / 2, y: frame.size.height / 2)
    floor.zPosition = 0
    floor.physicsBody?.mass = 0
    addChild(floor)
        
    leftBoundary.alpha = 1
    leftBoundary.position = CGPoint(x: frame.size.width / 3.89, y: frame.midY)
    leftBoundary.zPosition = 0
    leftBoundary.physicsBody?.mass = 0
    addChild(leftBoundary)
    
    rightBoundary.alpha = 1
    rightBoundary.position = CGPoint(x: frame.size.width / 1.33, y: frame.midY)
    rightBoundary.zPosition = 0
    rightBoundary.physicsBody?.mass = 0
    addChild(rightBoundary)
        
    }
}

struct Prologue: View {
    
    @ObservedObject var scene: MainHall = {
        let scene = MainHall()
        scene.size = CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        scene.scaleMode = .fill
        return scene
    }()
    
    var scene2: ScienceScene {
        let scene = ScienceScene()
        scene.size = CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        scene.scaleMode = .aspectFit
        return scene
    }
    
    var scene3: MathScene {
        let scene = MathScene()
        scene.size = CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        scene.scaleMode = .aspectFit
        return scene
    }
            
    var body: some View {
        NavigationView {
        ZStack(alignment: .bottom) {
        GeometryReader { geometry in
        if scene.Btnaction == 0 {
        SpriteView(scene: scene)
            .frame(width: geometry.size.width, height: geometry.size.height)
        } else if scene.Btnaction == 1 {
            SpriteView(scene: scene2)
            .frame(width: geometry.size.width, height: geometry.size.height)
        } else {
            SpriteView(scene: scene3)
            .frame(width: geometry.size.width, height: geometry.size.height)
            }
        }
        .ignoresSafeArea()
        NavigationLink(destination: Disillusion()) {
        Text("Once you're done with school, click here to go back home.")
            .font(.system(size: 15))
            .foregroundColor(Color.black)
            .background(Color.white)
            .opacity(scene.Btnaction == 1 ? 1:0)
          }
         }
      }
        .navigationViewStyle(StackNavigationViewStyle())
        .navigationBarHidden(true)
        .navigationBarBackButtonHidden(true)
    }
}
