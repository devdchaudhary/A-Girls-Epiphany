//
//  Hope.swift
//  A Girl's Epiphany
//
//  Created by Devanshu Dev Chaudhary on 07/04/22.
//

import SwiftUI
import AVKit

struct Question: View {
    
    var question: String
    
    init(_ question: String) {
        self.question = question
    }
    
    var body: some View {
        
        Text(question)
            .font(.system(size: 20, weight: .regular))
            .foregroundColor(.black)
            .padding()
            .shadow(radius: 10)
    }
}

struct Answer: View {
    
    var answer: String
    
    init(_ answer: String) {
        self.answer = answer
    }
    
    var body: some View {
        
            Text(answer)
                .foregroundColor(Color.black)
                .font(.system(size: 16.0, weight: .medium))
                .frame(width: 530, height: 55)
                .shadow(radius: 10)
                .clipShape(RoundedRectangle(cornerRadius: 10))
    }
}

public struct Hope: View {
        
    @State private var correctscorePlacard = false
    @State private var currentQues = 0
    @State private var option1Tap = false
    @State private var option2Tap = false
    @State private var option3Tap = false
    @State private var option4Tap = false
    @State private var showContinue = false
    @State private var firstFalse = false
    @State private var secondFalse = false
    @State private var thirdFalse = false
    @State private var fourthFalse = false
    
    let Script = "Now feeling a bit relaxed and confident from the sorrow state of mind that she was previously in, Swana tries to bring her focus back on her studies and get's down to do her homework for the day. But before she decides to take any steps further she first tries to assess the situation so as to avoid any such trauma in the future and be able to deal with any such incident in the future right at the spot and avoid having feelings of regret later on. There are five questions and you have to choose the correct answer for each to move to the next one, once you're done with that you can move to the next level."
    
    let questionsList: [String] = [
        "What should Swana have immediately done when she heard what they said?",
        "What was it that stopped Swana from being able to take such a step?",
        "What should Swana have done when she got back home",
        "What is it that one needs before they start affirming themselves?",
        "What should Swana do if she ever gets bullied in the future?",
    ]
    
    let answersList: [[String]] = [
        [   "Hide under her desk",
            "Be quiet and ignore them",
            "Fight back with all her force and punch them as hard as possible",
            "Complain to a teacher" ],
        [   "Fear",
            "Uncertainty",
            "Doubt",
            "All of the above" ],
        [   "Hide it from her parents",
            "Tell her parents about her feelings",
            "Berate hereself for not doing anything in school",
            "Regret and cry about the whole issue"],
        [   "Faith",
            "Hope",
            "Belief",
            "All of the above" ],
        [   "Give up",
            "Stand up to her bullies non violently.",
            "Blame others and herself",
            "Quietly give in and endure" ]]
    
    let rightAnswer: [Int] = [3,3,1,3,1]
    
    let correctanswersList: [String] = [
        "Very good! In such a situation it is imperative to be calm, not be violent and inform a member of faculty right away.",
        "Yes! It was a combination of all the above three that stopped Swana from being able to complain to her teacher and tell what exactly she was going through at the time. In such a situation where a person faces a sudden trauma it can be difficult to speak your mind and express your feelings as it is difficult to come out of the panicked state of mind.",
        "Correct! Hiding such an incident from your close ones only further exacerbates the problem and can lead to serious mental health issues later on. One has to be brave enough to be able to speak out!",
        "Exactly! It takes a combination of all three above to be able to overcome our fears, doubts & uncertainties. Hope being the most important one as it is the core of what makes us optimistic when it seems like everything around us is lost.",
        "Precisely! An eye for an eye makes the whole world blind. It may seem extremely tempting at first to give in to our worst instincts but one must always be grounded and remember in such situations that there are other ways to acheive outcomes. It is imperative that one acts mature when the other behaving immaturely. When one person becoms hot tempered the other must remember to stay cool."
    ]
            
    public var body: some View {
        
        NavigationView {
            
        ZStack {
            
            Color(floorColor)
                .ignoresSafeArea()
                        
            VStack(spacing: 20) {
                
                Text(Script)
                    .font(.system(size: 15, weight: .regular))
                    .foregroundColor(.black)
                    .padding()
                    .shadow(radius: 10)
                                
                Question(questionsList[currentQues])
                    Button(action: {
                        if(rightAnswer[currentQues] != 0) {
                            option1Tap = true
                            firstFalse = true
                        } else {
                            correctscorePlacard = true
                    }}) {
                        Answer(answersList[currentQues][0])
                    }
                
                    Button(action: {
                        if(rightAnswer[currentQues] != 1) {
                            option2Tap = true
                                secondFalse = true
                        } else {
                            correctscorePlacard.toggle()
                        }
                    }){
                        Answer(answersList[currentQues][1])
                    }
                
                    Button(action: {
                        if(rightAnswer[currentQues] != 2) {
                            option3Tap = true
                            thirdFalse = true
                        } else {
                            correctscorePlacard = true
                        }
                    }){
                        Answer(answersList[currentQues][2])
                    }
                
                    Button(action: {
                        if(rightAnswer[currentQues] != 3) {
                            option4Tap = true
                            fourthFalse = true
                        } else {
                            correctscorePlacard = true
                        }
                    }){
                        Answer(answersList[currentQues][3])
                    }
            }
            
            Spacer()
                        
            VStack(spacing: 5) {
                                                
                Text((currentQues == 4) ? "Congrats!" : "👍")
                    .font(.system(size: 30))
                    .foregroundColor(Color.black)
                                
                Text(correctanswersList[currentQues])
                    .font(.system(size: 13))
                    .foregroundColor(Color.black)
                    .padding(.vertical, 10)
                    .padding(.horizontal, 20)
                    .padding(.top, 20)
                
                NavigationLink(destination: Moral(), isActive: $showContinue) {
                Button(action: {
                    correctscorePlacard.toggle()
                    if(currentQues != 4) {
                        currentQues = currentQues + 1
                        firstFalse = false; secondFalse = false; thirdFalse = false; fourthFalse = false; option1Tap = false; option2Tap = false; option3Tap = false; option4Tap = false
                    } else if currentQues == 0 {
                        currentQues = 0
                        firstFalse = false; secondFalse = false; thirdFalse = false; fourthFalse = false; option1Tap = false; option2Tap = false; option3Tap = false; option4Tap = false
                    } else {
                        showContinue = true
                    }}) {
                    Text((currentQues == 4) ? "Next Level" : "Next Question")
                        .font(.system(size: 20, weight: .bold))
                        .foregroundColor(Color(carpetColor))
                    }
                }
                .frame(width: 450, height: 300, alignment: .center)
                .padding(.horizontal, 20)
                .padding(.bottom, 5)
            }
            .frame(width: 500, height: 600, alignment: .center)
            .background(Color(floorColor))
            .cornerRadius(10)
            .opacity(correctscorePlacard ? 1.0 : 0.0)
            .shadow(radius: 30)
        }
        .statusBar(hidden: true)
        }
        .navigationViewStyle(StackNavigationViewStyle())
        .navigationBarHidden(true)
        .navigationBarBackButtonHidden(true)
    }
}
