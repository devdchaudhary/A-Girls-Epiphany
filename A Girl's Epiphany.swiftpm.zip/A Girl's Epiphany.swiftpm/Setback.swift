//
//  Setback.swift
//  A Girl's Epiphany
//
// Created by Devanshu Dev Chaudhary on 07/04/22.
//

import UIKit
import SwiftUI
import SpriteKit
import AVFoundation
import AVKit

class ScienceScene: SKScene {
           
    private var tapSoundEffect: AVAudioPlayer?
    private let swana = SKSpriteNode(imageNamed: "Swana_normal")
    private let table = SKSpriteNode(color: .brown, size: CGSize(width: 150, height: 100))
    private let floor = SKSpriteNode(color: floorColor, size: CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height))
    private let upperBoundary = SKSpriteNode(color: .brown, size: CGSize(width: UIScreen.main.bounds.width, height: 50))
    private let lowerBoundary = SKSpriteNode(color: .brown, size: CGSize(width: UIScreen.main.bounds.width, height: 50))
    private let paper = SKSpriteNode(color: .white, size: CGSize(width: 40, height: 60))
    private let chair = SKSpriteNode(color: .black, size: CGSize(width: 50, height: 10))
    private let carpet = SKSpriteNode(color: carpetColor, size: CGSize(width: 475, height: 185))
    private let stuTable = SKSpriteNode(color: stuTableColor, size: CGSize(width: 200, height: 50))
    private let stuBench = SKSpriteNode(color: .systemGray2, size: CGSize(width: 180, height: 20))
    private let stuTable2 = SKSpriteNode(color: stuTableColor, size: CGSize(width: 200, height: 50))
    private let stuBench2 = SKSpriteNode(color: .systemGray2, size: CGSize(width: 180, height: 20))
    private let stuTable3 = SKSpriteNode(color: stuTableColor, size: CGSize(width: 200, height: 50))
    private let stuBench3 = SKSpriteNode(color: .systemGray2, size: CGSize(width: 180, height: 20))
    private let stuTable4 = SKSpriteNode(color: stuTableColor, size: CGSize(width: 200, height: 50))
    private let stuBench4 = SKSpriteNode(color: .systemGray2, size: CGSize(width: 180, height: 20))
    private let fadeIn = SKAction.fadeIn(withDuration: 4)
    private let fadeOut = SKAction.fadeOut(withDuration: 4)
    private let Bubble = SKSpriteNode(imageNamed: "bubble.png")
    private let Bubble2 = SKSpriteNode(imageNamed: "bubble.png")
    private let textlabel = SKLabelNode(fontNamed: "Helvetica")
    private let textlabel2 = SKLabelNode(fontNamed: "Helvetica")
    private let textlabel3 = SKLabelNode(fontNamed: "Helvetica")
    private let textlabel4 = SKLabelNode(fontNamed:"Helvetica")
    private let textlabel5 = SKLabelNode(fontNamed:"Helvetica")
    private let g1 = SKVideoNode(fileNamed: "Girl1.mov")
    private let g2 = SKVideoNode(fileNamed: "Girl2.mov")

    override func didMove(to view: SKView) {
        physicsBody = SKPhysicsBody(edgeLoopFrom: frame)
        intro()
        DispatchQueue.main.asyncAfter(deadline: .now() + 5) { [self] in
        scene?.removeAllChildren()
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) { [self] in
        game()
    }}}
    
    func game() {
        Swana()
        bottom()
        boundaries()
        tableFunc()
        student1()
        student2()
        student3()
        student4()
    }
    
    func squaredDistance(p1: CGPoint, p2: CGPoint) -> CGFloat {
        return pow(p2.x - p1.x, 2) + pow(p2.x - p1.x, 2)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        tapSound()
    }
     
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        for touch in touches {
            
            let location = touch.location(in: self)
            
            swana.position.x = location.x
            swana.position.y = location.y
            
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        let nodesToDetect = [swana, stuTable2]
        
        let squaredRadius: CGFloat = 15 * 15
        for _ in nodesToDetect {
            if squaredDistance(p1: swana.position, p2: stuTable2.position) < squaredRadius {
                gameOver()
            }
        }
    }
    
    func intro() {
                
        textlabel4.text = "Swana has just started her first lecture for the day - English."
        textlabel4.alpha = 1
        textlabel4.zPosition = 2
        textlabel4.fontSize = 20
        textlabel4.position = CGPoint(x: frame.midX, y: frame.height - 250)
        textlabel4.fontColor = .white
        addChild(textlabel4)
        
        textlabel5.text = "Drag Swana to the middle of the second table in front of the class."
        textlabel5.alpha = 1
        textlabel5.zPosition = 2
        textlabel5.fontSize = 20
        textlabel5.position = CGPoint(x: frame.midX, y: frame.height - 300)
        textlabel5.fontColor = .white
        addChild(textlabel5)
        
    }
    
    func gameOver() {
    
    scene?.removeAllChildren()
            
    speechBubble()
    speechBubble2()
    Bubble.run(fadeIn)
    textlabel.run(fadeIn)
    textlabel2.run(fadeIn)
                        
    g1.position = CGPoint(x: frame.midX - 200,
                                  y: frame.midY)
    g1.size = CGSize(width: 350, height: 290)
    addChild(g1)
    g1.play()
        
    g2.position = CGPoint(x: frame.midX + 200,
                                      y: frame.midY)
    g2.size = CGSize(width: 350, height: 290)
    addChild(g2)
    DispatchQueue.main.asyncAfter(deadline: .now() + 5) { [self] in
    Bubble2.run(fadeIn)
    textlabel3.run(fadeIn)
    g2.play()
    DispatchQueue.main.asyncAfter(deadline: .now() + 6) { [self] in
    let strikeTwo = MathScene(size: CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height))
    scene?.view?.presentScene(strikeTwo, transition: .crossFade(withDuration: 1))
    scene?.removeAllChildren()
    scene?.removeAllActions()
    }}}
    
    func speechBubble() {
        
    Bubble.alpha = 0
    Bubble.zPosition = 0
    Bubble.position = CGPoint(x: frame.midX + 50, y: g1.position.y + 200)
    Bubble.size = CGSize(width: 400, height: 100)
    Bubble.xScale = -1.0
    textlabel.text = "Hey did you see that new girl who just joined class today?"
    textlabel2.text =  "I wonder why she looks so different from us."
    textlabel.alpha = 0
    textlabel2.alpha = 0
    textlabel.zPosition = 1
    textlabel2.zPosition = 1
    textlabel.fontSize = 13
    textlabel2.fontSize = 13
    textlabel.position = CGPoint(x: Bubble.frame.midX + 10, y: Bubble.frame.midY)
    textlabel2.position = CGPoint(x: Bubble.frame.midX + 10, y: Bubble.frame.midY - 25)
    textlabel.fontColor = .black
    textlabel2.fontColor = .black
    addChild(Bubble)
    addChild(textlabel)
    addChild(textlabel2)

    }
    
    func speechBubble2() {
        
    Bubble2.alpha = 0
    Bubble2.zPosition = 0
    Bubble2.position = CGPoint(x: frame.midX + 100, y: g2.position.y - 200)
    Bubble2.size = CGSize(width: 100, height: 300)
    Bubble2.zRotation = .pi/2
    textlabel3.text = "I know right! I wonder where she's from..."
    textlabel3.alpha = 0
    textlabel3.zPosition = 1
    textlabel3.fontSize = 13
    textlabel3.position = CGPoint(x: Bubble2.frame.midX, y: Bubble2.frame.midY)
    textlabel3.fontColor = .black
    addChild(Bubble2)
    addChild(textlabel3)

    }

    func tapSound() {
           
        let path = Bundle.main.path(forResource: "Tap Sound", ofType: "wav")!
        let url = URL(fileURLWithPath: path)
        
        do {
            
            tapSoundEffect = try AVAudioPlayer(contentsOf: url)
            
            tapSoundEffect?.play()
            
        }
            
        catch {
            
        }
    }
    
    func Swana() {
       
    swana.alpha = 1
    swana.position = CGPoint(x: frame.midX, y: frame.midY)
    swana.size = CGSize(width: 75, height: 75)
    swana.zPosition = 1
    swana.physicsBody?.mass = 0
    swana.physicsBody = SKPhysicsBody(circleOfRadius: swana.size.width / 2)
    swana.physicsBody?.affectedByGravity = false
    swana.physicsBody?.isDynamic = false
    swana.physicsBody?.allowsRotation = false
    addChild(swana)
        
    }
    
    func bottom() {
        
        floor.alpha = 1
        floor.position = CGPoint(x: frame.size.width / 2, y: frame.size.height / 2)
        floor.zPosition = 0
        floor.physicsBody?.mass = 0
        floor.physicsBody = SKPhysicsBody(circleOfRadius: floor.size.width / 2)
        floor.physicsBody?.affectedByGravity = false
        floor.physicsBody?.isDynamic = false
        floor.physicsBody?.allowsRotation = false
        addChild(floor)
        
    }
    
    func boundaries() {
        
        upperBoundary.alpha = 1
        upperBoundary.position = CGPoint(x: frame.size.width / 2, y: 0)
        upperBoundary.zPosition = 0
        upperBoundary.physicsBody?.mass = 0
        upperBoundary.physicsBody = SKPhysicsBody(circleOfRadius: upperBoundary.size.width / 2)
        upperBoundary.physicsBody?.affectedByGravity = false
        upperBoundary.physicsBody?.isDynamic = false
        upperBoundary.physicsBody?.allowsRotation = false
        addChild(upperBoundary)
    
        lowerBoundary.alpha = 1
        lowerBoundary.position = CGPoint(x: frame.midX, y: frame.maxY)
        lowerBoundary.zPosition = 0
        lowerBoundary.physicsBody?.mass = 0
        lowerBoundary.physicsBody = SKPhysicsBody(circleOfRadius: lowerBoundary.size.width / 2)
        lowerBoundary.physicsBody?.affectedByGravity = false
        lowerBoundary.physicsBody?.isDynamic = false
        lowerBoundary.physicsBody?.allowsRotation = false
        addChild(lowerBoundary)
    }
    
    func tableFunc() {
        
        carpet.alpha = 1
        carpet.position = CGPoint(x: frame.size.width / 2, y: 650)
        carpet.zPosition = 0
        carpet.physicsBody?.mass = 0
        carpet.physicsBody = SKPhysicsBody(circleOfRadius: carpet.size.width / 2)
        carpet.physicsBody?.affectedByGravity = false
        carpet.physicsBody?.isDynamic = false
        carpet.physicsBody?.allowsRotation = false
        addChild(carpet)
        
        table.alpha = 1
        table.position = CGPoint(x: frame.size.width / 2.45, y: 670)
        table.zPosition = 0
        table.physicsBody?.mass = 0
        table.physicsBody = SKPhysicsBody(circleOfRadius: table.size.width / 2)
        table.physicsBody?.affectedByGravity = false
        table.physicsBody?.isDynamic = false
        table.physicsBody?.allowsRotation = false
        addChild(table)
        
        chair.alpha = 1
        chair.position = CGPoint(x: frame.size.width / 2.45, y: 720)
        chair.zPosition = 0
        chair.physicsBody?.mass = 0
        chair.physicsBody = SKPhysicsBody(circleOfRadius: chair.size.width / 2)
        chair.physicsBody?.affectedByGravity = false
        chair.physicsBody?.isDynamic = false
        chair.physicsBody?.allowsRotation = false
        addChild(chair)

        paper.alpha = 1
        paper.position = CGPoint(x: frame.size.width / 2.45, y: 670)
        paper.zPosition = 0
        paper.physicsBody?.mass = 0
        paper.physicsBody = SKPhysicsBody(circleOfRadius: paper.size.width / 2)
        paper.physicsBody?.affectedByGravity = false
        paper.physicsBody?.isDynamic = false
        paper.physicsBody?.allowsRotation = false
        addChild(paper)
        
    }
    
    func student1() {
        
        stuBench.alpha = 1
        stuBench.position = CGPoint(x: frame.size.width / 2.7, y: 375)
        stuBench.zPosition = 0
        stuBench.physicsBody?.mass = 0
        stuBench.physicsBody = SKPhysicsBody(circleOfRadius: stuBench.size.width / 2)
        stuBench.physicsBody?.affectedByGravity = false
        stuBench.physicsBody?.isDynamic = false
        stuBench.physicsBody?.allowsRotation = false
        addChild(stuBench)

        stuTable.alpha = 1
        stuTable.position = CGPoint(x: frame.size.width / 2.7, y: 400)
        stuTable.zPosition = 0
        stuTable.physicsBody?.mass = 0
        stuTable.physicsBody = SKPhysicsBody(circleOfRadius: stuTable.size.width / 2)
        stuTable.physicsBody?.affectedByGravity = false
        stuTable.physicsBody?.isDynamic = false
        stuTable.physicsBody?.allowsRotation = false
        addChild(stuTable)
            
    }
    
    func student2() {
        
        stuBench2.alpha = 1
        stuBench2.position = CGPoint(x: frame.size.width / 1.47, y: 375)
        stuBench2.zPosition = 0
        stuBench2.physicsBody?.mass = 0
        stuBench2.physicsBody = SKPhysicsBody(rectangleOf: stuBench2.size)
        stuBench2.physicsBody?.affectedByGravity = false
        stuBench2.physicsBody?.isDynamic = false
        stuBench2.physicsBody?.allowsRotation = false
        addChild(stuBench2)

        stuTable2.alpha = 1
        stuTable2.position = CGPoint(x: frame.size.width / 1.47, y: 400)
        stuTable2.zPosition = 0
        stuTable2.physicsBody?.mass = 0
        stuTable2.physicsBody = SKPhysicsBody(circleOfRadius: stuTable2.size.width / 2)
        stuTable2.physicsBody?.affectedByGravity = false
        stuTable2.physicsBody?.isDynamic = false
        stuTable2.physicsBody?.allowsRotation = false
        addChild(stuTable2)
            
    }
    
    func student3() {
        
        stuBench3.alpha = 1
        stuBench3.position = CGPoint(x: frame.size.width / 2.7, y: 175)
        stuBench3.zPosition = 0
        stuBench3.physicsBody?.mass = 0
        stuBench3.physicsBody = SKPhysicsBody(circleOfRadius: stuBench3.size.width / 2)
        stuBench3.physicsBody?.affectedByGravity = false
        stuBench3.physicsBody?.isDynamic = false
        stuBench3.physicsBody?.allowsRotation = false
        addChild(stuBench3)

        stuTable3.alpha = 1
        stuTable3.position = CGPoint(x: frame.size.width / 2.7, y: 200)
        stuTable3.zPosition = 0
        stuTable3.physicsBody?.mass = 0
        stuTable3.physicsBody = SKPhysicsBody(circleOfRadius: stuTable3.size.width / 2)
        stuTable3.physicsBody?.affectedByGravity = false
        stuTable3.physicsBody?.isDynamic = false
        stuTable3.physicsBody?.allowsRotation = false
        addChild(stuTable3)
            
    }
    
    func student4() {
        
        stuBench4.alpha = 1
        stuBench4.position = CGPoint(x: frame.size.width / 1.47, y: 175)
        stuBench4.zPosition = 0
        stuBench4.physicsBody?.mass = 0
        stuBench4.physicsBody = SKPhysicsBody(circleOfRadius: stuBench4.size.width / 2)
        stuBench4.physicsBody?.affectedByGravity = false
        stuBench4.physicsBody?.isDynamic = false
        stuBench4.physicsBody?.allowsRotation = false
        addChild(stuBench4)

        stuTable4.alpha = 1
        stuTable4.position = CGPoint(x: frame.size.width / 1.47, y: 200)
        stuTable4.zPosition = 0
        stuTable4.physicsBody?.mass = 0
        stuTable4.physicsBody = SKPhysicsBody(circleOfRadius: stuTable4.size.width / 2)
        stuTable4.physicsBody?.affectedByGravity = false
        stuTable4.physicsBody?.isDynamic = false
        stuTable4.physicsBody?.allowsRotation = false
        addChild(stuTable4)
            
    }
}
