//
//  Moral.swift
//  A Girl's Epiphany
//
//  Created by Devanshu Dev Chaudhary on 07/04/22.
//

import SwiftUI

public struct Moral: View {
    
    @State private var Script = "In an ideal world no kid should have to live in fear and go through such a traumatic incident like Swana did, and all kids should be able to safely and securely be able to complete their education in a free and secure environment. If the situation ever comes be able to tell their experiences and what they feel within without having to live through the fear of being judged by someone else. In such a world parents as well as teachers would work with the child to ensure that such instances are never repeated, unfortunately however we don't live in such a world and bullying and it's consequences are serious issues faced by kids all over the world. Not every kid in this world gets to comes out of such trauma in a brave and sensible manner like Swana, for alot of them this is the beginning of going down a darker path that they might never be able to return from, and this creates a new cycle of violence that the next generation inherits from."
    @State private var Fact2 = "* Almost one-third of young teens worldwide have recently experienced bullying, according to data released for the first time by the UNESCO Institute for Statistics Over 160,000 kids refuse to go to school each day for fear of being bullied."
    @State private var Fact3 = "* Research has shown that students belonging to various minority groups are often more likely to be bullied. These groups include students with disabilities, LGBT students and  minority students."
    @State private var Fact4 = "* Statistics suggest that revenge [due to bullying] is the number one motivator for school shootings in the U.S."
    @State private var Conclu1 = "The words that come out of our mouth are very important and can go a long way in determining how some else feels, it can make or break them. I hope that through my app have been able to teach you about the importance of positive thinking, self affirmations and to be kind to not only others but also to yourself."
    @State private var Conclu2 = ""
    @State private var Title = "A Girl's Epiphany - A Swift Playgrounds App built using Xcode"
    @State private var Title3 = "All textures & graphics used were made using Spritekit"
    @State private var Title4 = "Faces used were made using my own face recording through Animojis - a technology created by Apple"
    @State private var Title5 = "All sound effects used are my own voice & all speech is processed offline"
    @State private var Title7 = "Created for all the swana's & non - swana's out there... by Devanshu Dev Chaudhary"
    @State private var buttonState = true
                 
    public var body: some View {
        NavigationView {
        ZStack {
            Color(floorColor)
                .ignoresSafeArea()
        VStack(spacing: 30) {
            
            Text(Script)
                .font(.system(size: 12))
                .foregroundColor(.black)
            
            Text(Fact2)
                .font(.system(size: 15))
                .foregroundColor(.black)
            
            Text(Fact3)
                .font(.system(size: 15))
                .foregroundColor(.black)
            
            Text(Fact4)
                .font(.system(size: 15))
                .foregroundColor(.black)
            
            Text(Conclu1)
                .font(.system(size: 15))
                .foregroundColor(.black)
            
            Text(Title)
                .font(.system(size: 15))
                .foregroundColor(.black)
            
            Text(Title3)
                .font(.system(size: 15))
                .foregroundColor(.black)
            
            Text(Title4)
                .font(.system(size: 15))
                .foregroundColor(.black)
            
            Text(Title5)
                .font(.system(size: 15))
                .foregroundColor(.black)
            
            Text(Title7)
                .font(.system(size: 15))
                .foregroundColor(.black)
            
          }
        .padding()
        }
    }
        .navigationViewStyle(StackNavigationViewStyle())
        .navigationBarHidden(true)
        .navigationBarBackButtonHidden(true)
   }
}
