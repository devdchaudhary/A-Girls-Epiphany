//
//  Strike Two.swift
//  A Girl's Epiphany
//
//  Created by Devanshu Dev Chaudhary on 07/04/22.
//

import SpriteKit
import SwiftUI
import AVFoundation

class MathScene: SKScene {
    
    private let benchHitCategory: UInt32 = 2
    private let SwanaHitCategory: UInt32 = 1
    private let defaultHitCategory: UInt32 = 0
           
    private var tapSoundEffect: AVAudioPlayer?
    private var cryEffect: AVAudioPlayer?
    private let swana = SKSpriteNode(imageNamed: "Swana_sad")
    private let teardrop = SKShapeNode(circleOfRadius: 100)
    private let table = SKSpriteNode(color: .brown, size: CGSize(width: 150, height: 100))
    private let floor = SKSpriteNode(color: floorColor, size: CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height))
    private let upperBoundary = SKSpriteNode(color: .brown, size: CGSize(width: UIScreen.main.bounds.width, height: 50))
    private let lowerBoundary = SKSpriteNode(color: .brown, size: CGSize(width: UIScreen.main.bounds.width, height: 50))
    private let paper = SKSpriteNode(color: .white, size: CGSize(width: 40, height: 60))
    private let chair = SKSpriteNode(color: .black, size: CGSize(width: 50, height: 10))
    private let carpet = SKSpriteNode(color: carpetColor, size: CGSize(width: 475, height: 185))
    private let stuTable = SKSpriteNode(color: stuTableColor, size: CGSize(width: 200, height: 50))
    private let stuBench = SKSpriteNode(color: .systemGray2, size: CGSize(width: 180, height: 20))
    private let stuTable2 = SKSpriteNode(color: stuTableColor, size: CGSize(width: 200, height: 50))
    private let stuBench2 = SKSpriteNode(color: .systemGray2, size: CGSize(width: 180, height: 20))
    private let stuTable3 = SKSpriteNode(color: stuTableColor, size: CGSize(width: 200, height: 50))
    private let stuBench3 = SKSpriteNode(color: .systemGray2, size: CGSize(width: 180, height: 20))
    private let stuTable4 = SKSpriteNode(color: stuTableColor, size: CGSize(width: 200, height: 50))
    private let stuBench4 = SKSpriteNode(color: .systemGray2, size: CGSize(width: 180, height: 20))
    private let fadeIn = SKAction.fadeIn(withDuration: 4)
    private let fadeOut = SKAction.fadeOut(withDuration: 4)
    private let paperTitle = SKLabelNode(fontNamed: "Helvetica")
    private let testTitle = SKLabelNode(fontNamed: "Helvetica")
    private let Q1 = SKLabelNode(fontNamed: "Helvetica")
    private let Q2 = SKLabelNode(fontNamed: "Helvetica")
    private let Q3 = SKLabelNode(fontNamed: "Helvetica")
    private let textlabel4 = SKLabelNode(fontNamed:"Helvetica")
    private let textlabel5 = SKLabelNode(fontNamed:"Helvetica")
    private let textlabel6 = SKLabelNode(fontNamed:"Helvetica")
    private let textlabel7 = SKLabelNode(fontNamed:"Helvetica")
    private let textlabel8 = SKLabelNode(fontNamed:"Helvetica")
    private let textlabel9 = SKLabelNode(fontNamed:"Helvetica")
    
    override func didMove(to view: SKView) {
        physicsBody = SKPhysicsBody(edgeLoopFrom: frame)
        intro()
        DispatchQueue.main.asyncAfter(deadline: .now() + 7) { [self] in
        scene?.removeAllChildren()
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) { [self] in
        game()
        }}}
    
    func game() {
        Swana()
        bottom()
        boundaries()
        tableFunc()
        student1()
        student2()
        student3()
        student4()
    }
    
    func squaredDistance(p1: CGPoint, p2: CGPoint) -> CGFloat {
        return pow(p2.x - p1.x, 2) + pow(p2.x - p1.x, 2)
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        for touch in touches {
            
            let location = touch.location(in: self)
            
            swana.position.x = location.x
            swana.position.y = location.y
            
        }
    }
     
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        let nodesToDetect = [swana, stuTable4]

        let squaredRadius: CGFloat = 15 * 15
        for _ in nodesToDetect {
            if squaredDistance(p1: swana.position, p2: stuTable4.position) < squaredRadius {
                gameOver()
            }
        }
    }
    
    func intro() {
        textlabel4.text = "Uh oh, it seems like swana hasn't had a very warm welcome to her new class."
        textlabel4.alpha = 1
        textlabel4.zPosition = 2
        textlabel4.fontSize = 15
        textlabel4.position = CGPoint(x: frame.midX, y: frame.height - 100)
        textlabel4.fontColor = .white
        addChild(textlabel4)
                
        textlabel6.text = "Having finished Science lecture, it is now time for Swana to go to her second lecture - Math."
        textlabel6.alpha = 1
        textlabel6.zPosition = 2
        textlabel6.fontSize = 15
        textlabel6.position = CGPoint(x: frame.midX, y: frame.height - 125)
        textlabel6.fontColor = .white
        addChild(textlabel6)
        
        textlabel7.text = "It turns out there's a surprise test happening today and every student must complete it before the lecture is over."
        textlabel7.alpha = 1
        textlabel7.zPosition = 2
        textlabel7.fontSize = 15
        textlabel7.position = CGPoint(x: frame.midX, y: frame.height - 150)
        textlabel7.fontColor = .white
        addChild(textlabel7)
        
        textlabel8.text = "Swana, doesn't feel so good after her previous class"
        textlabel8.alpha = 1
        textlabel8.zPosition = 2
        textlabel8.fontSize = 15
        textlabel8.position = CGPoint(x: frame.midX, y: frame.height - 175)
        textlabel8.fontColor = .white
        addChild(textlabel8)
        
        textlabel5.text = "and decides to go and sit down at the bench farthest away from the rest of the class."
        textlabel5.alpha = 1
        textlabel5.zPosition = 2
        textlabel5.fontSize = 15
        textlabel5.position = CGPoint(x: frame.midX, y: frame.height - 200)
        textlabel5.fontColor = .white
        addChild(textlabel5)
        
        textlabel9.text = "Drag and drop swana to the middle of the corner most bench in the whole class."
        textlabel9.alpha = 1
        textlabel9.zPosition = 2
        textlabel9.fontSize = 15
        textlabel9.position = CGPoint(x: frame.midX, y: frame.height - 225)
        textlabel9.fontColor = .white
        addChild(textlabel9)
    
    }

    func gameOver() {
    
    scene?.removeAllChildren()
        
    randomTeardrop()
        
    cryingSound()
                
    let tableZoomed = SKSpriteNode(color: stuTableColor, size: CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height))
    tableZoomed.alpha = 1
    tableZoomed.position = CGPoint(x: frame.midX, y: frame.midY)
    tableZoomed.zPosition = 0
    tableZoomed.physicsBody?.mass = 0
    tableZoomed.physicsBody = SKPhysicsBody(circleOfRadius: floor.size.width / 2)
    tableZoomed.physicsBody?.affectedByGravity = false
    tableZoomed.physicsBody?.isDynamic = false
    tableZoomed.physicsBody?.allowsRotation = false
    tableZoomed.physicsBody?.categoryBitMask = defaultHitCategory
    tableZoomed.physicsBody?.collisionBitMask = defaultHitCategory
    tableZoomed.physicsBody?.contactTestBitMask = defaultHitCategory
    addChild(tableZoomed)
    
    let testPaper = SKSpriteNode(color: .white, size: CGSize(width: 450, height: 700))
    testPaper.alpha = 1
    testPaper.position = CGPoint(x: frame.midX, y: frame.midY)
    testPaper.zPosition = 1
    testPaper.physicsBody = SKPhysicsBody(circleOfRadius: floor.size.width / 2)
    testPaper.physicsBody?.affectedByGravity = false
    testPaper.physicsBody?.isDynamic = false
    testPaper.physicsBody?.allowsRotation = false
    testPaper.physicsBody?.categoryBitMask = defaultHitCategory
    testPaper.physicsBody?.collisionBitMask = defaultHitCategory
    testPaper.physicsBody?.contactTestBitMask = defaultHitCategory
    addChild(testPaper)
        
    testTitle.alpha = 1
    testTitle.text = "Grade VII"
    testTitle.position = CGPoint(x: testPaper.frame.midX, y: testPaper.frame.midY + 300)
    testTitle.zPosition = 2
    testTitle.fontColor = .black
    testTitle.fontSize = 24
    testTitle.physicsBody?.affectedByGravity = false
    testTitle.physicsBody?.isDynamic = false
    testTitle.physicsBody?.allowsRotation = false
    addChild(testTitle)
    
    paperTitle.alpha = 1
    paperTitle.text = " SURPRISE TEST"
    paperTitle.position = CGPoint(x: testPaper.frame.midX, y: testPaper.frame.midY + 200)
    paperTitle.zPosition = 2
    paperTitle.fontColor = .black
    paperTitle.fontSize = 24
    paperTitle.physicsBody?.affectedByGravity = false
    paperTitle.physicsBody?.isDynamic = false
    paperTitle.physicsBody?.allowsRotation = false
    addChild(paperTitle)
        
    Q1.alpha = 1
    Q1.text = "Q1. Solve for x: 2(3x + 4) - 3(x - 1) = x - 1"
    Q1.position = CGPoint(x: testPaper.frame.midX - 100, y: testPaper.frame.midY + 100)
    Q1.zPosition = 2
    Q1.fontColor = .black
    Q1.fontSize = 10
    Q1.physicsBody?.affectedByGravity = false
    Q1.physicsBody?.isDynamic = false
    Q1.physicsBody?.allowsRotation = false
    addChild(Q1)
        
    Q2.alpha = 1
    Q2.text = "Q2. What is the slope of the line through the points (4, -7) and (9, 2)?"
    Q2.position = CGPoint(x: testPaper.frame.midX - 40, y: testPaper.frame.midY)
    Q2.zPosition = 2
    Q2.fontColor = .black
    Q2.fontSize = 10
    Q2.physicsBody?.affectedByGravity = false
    Q2.physicsBody?.isDynamic = false
    Q2.physicsBody?.allowsRotation = false
    addChild(Q2)
        
    Q3.alpha =  1
    Q3.text = "Q3. After a 20% discount and 6% tax, a guitar cost $530.00. What was the original price?"
    Q3.position = CGPoint(x: testPaper.frame.midX, y: testPaper.frame.midY - 100)
    Q3.zPosition = 2
    Q3.fontColor = .black
    Q3.fontSize = 10
    Q3.physicsBody?.affectedByGravity = false
    Q3.physicsBody?.isDynamic = false
    Q3.physicsBody?.allowsRotation = false
    addChild(Q3)
        
    DispatchQueue.main.asyncAfter(deadline: .now() + 11) { [self] in
        
    scene?.removeAllActions()
    scene?.removeAllChildren()

    }}
        
    func tapSound() {
           
        let path = Bundle.main.path(forResource: "Tap Sound", ofType: "wav")!
        let url = URL(fileURLWithPath: path)
        
        do {
            
            tapSoundEffect = try AVAudioPlayer(contentsOf: url)
            
            tapSoundEffect?.play()
            
        }
            
        catch {
            
        }
    }
    
    func cryingSound() {
           
        let path = Bundle.main.path(forResource: "crying", ofType: "wav")!
        let url = URL(fileURLWithPath: path)
        
        do {
            
            cryEffect = try AVAudioPlayer(contentsOf: url)
            
            cryEffect?.play()
            
        }
            
        catch {
            
        }
    }
    
//    func teardropSound() {
//
//        let path = Bundle.main.path(forResource: "teardrop", ofType: "wav")!
//        let url = URL(fileURLWithPath: path)
//
//        do {
//
//            cryEffect = try AVAudioPlayer(contentsOf: url)
//
//            cryEffect?.play()
//
//        }
//
//        catch {
//
//        }
//    }
    
    func randomTeardrop() {
        
    let height = UInt32(self.size.height)
    let width = UInt32(self.size.width)
    let randomPosition = CGPoint(x: Int(arc4random_uniform(width)), y: Int(arc4random_uniform(height)))
    let teardrop = SKShapeNode(circleOfRadius: 10)
    teardrop.alpha = 0.3
    teardrop.position = randomPosition
    teardrop.zPosition = 2
    teardrop.glowWidth = 10
    teardrop.fillColor = SKColor.systemBlue
    teardrop.physicsBody = SKPhysicsBody(circleOfRadius: 40)
    teardrop.physicsBody?.isDynamic = false
        
    let wait = SKAction.wait(forDuration: 3)
    let block = SKAction.run({
    [weak self] in

    self?.addChild(teardrop)
        
    self?.randomTeardrop()
            
    })

    let sequence = SKAction.sequence([wait, block])
    run(sequence)
        
    }
    
    func Swana() {
       
    swana.alpha = 1
    swana.position = CGPoint(x: frame.midX, y: frame.midY)
    swana.size = CGSize(width: 75, height: 75)
    swana.zPosition = 1
    swana.physicsBody?.mass = 0
    swana.physicsBody = SKPhysicsBody(circleOfRadius: swana.size.width / 2)
    swana.physicsBody?.affectedByGravity = false
    swana.physicsBody?.isDynamic = false
    swana.physicsBody?.allowsRotation = false
    swana.physicsBody?.categoryBitMask = benchHitCategory
    swana.physicsBody?.collisionBitMask = benchHitCategory
    swana.physicsBody?.contactTestBitMask = benchHitCategory
    addChild(swana)
        
    }
    
    func bottom() {
        
        floor.alpha = 1
        floor.position = CGPoint(x: frame.size.width / 2, y: frame.size.height / 2)
        floor.zPosition = 0
        floor.physicsBody?.mass = 0
        floor.physicsBody = SKPhysicsBody(circleOfRadius: floor.size.width / 2)
        floor.physicsBody?.affectedByGravity = false
        floor.physicsBody?.isDynamic = false
        floor.physicsBody?.allowsRotation = false
        floor.physicsBody?.categoryBitMask = defaultHitCategory
        floor.physicsBody?.collisionBitMask = defaultHitCategory
        floor.physicsBody?.contactTestBitMask = defaultHitCategory
        addChild(floor)
        
    }
    
    func boundaries() {
        
        upperBoundary.alpha = 1
        upperBoundary.position = CGPoint(x: frame.size.width / 2, y: 0)
        upperBoundary.zPosition = 0
        upperBoundary.physicsBody?.mass = 0
        upperBoundary.physicsBody = SKPhysicsBody(circleOfRadius: upperBoundary.size.width / 2)
        upperBoundary.physicsBody?.affectedByGravity = false
        upperBoundary.physicsBody?.isDynamic = false
        upperBoundary.physicsBody?.allowsRotation = false
        upperBoundary.physicsBody?.categoryBitMask = defaultHitCategory
        upperBoundary.physicsBody?.collisionBitMask = defaultHitCategory
        upperBoundary.physicsBody?.contactTestBitMask = defaultHitCategory
        addChild(upperBoundary)
    
        lowerBoundary.alpha = 1
        lowerBoundary.position = CGPoint(x: frame.midX, y: frame.maxY)
        lowerBoundary.zPosition = 0
        lowerBoundary.physicsBody?.mass = 0
        lowerBoundary.physicsBody = SKPhysicsBody(circleOfRadius: lowerBoundary.size.width / 2)
        lowerBoundary.physicsBody?.affectedByGravity = false
        lowerBoundary.physicsBody?.isDynamic = false
        lowerBoundary.physicsBody?.allowsRotation = false
        addChild(lowerBoundary)
        
    }
    
    func tableFunc() {
        
        carpet.alpha = 1
        carpet.position = CGPoint(x: frame.size.width / 2, y: 650)
        carpet.zPosition = 0
        carpet.physicsBody?.mass = 0
        carpet.physicsBody = SKPhysicsBody(circleOfRadius: carpet.size.width / 2)
        carpet.physicsBody?.affectedByGravity = false
        carpet.physicsBody?.isDynamic = false
        carpet.physicsBody?.allowsRotation = false
        carpet.physicsBody?.categoryBitMask = defaultHitCategory
        carpet.physicsBody?.collisionBitMask = defaultHitCategory
        carpet.physicsBody?.contactTestBitMask = defaultHitCategory
        addChild(carpet)
        
        table.alpha = 1
        table.position = CGPoint(x: frame.size.width / 2.45, y: 670)
        table.zPosition = 0
        table.physicsBody?.mass = 0
        table.physicsBody = SKPhysicsBody(circleOfRadius: table.size.width / 2)
        table.physicsBody?.affectedByGravity = false
        table.physicsBody?.isDynamic = false
        table.physicsBody?.allowsRotation = false
        table.physicsBody?.categoryBitMask = defaultHitCategory
        table.physicsBody?.collisionBitMask = defaultHitCategory
        table.physicsBody?.contactTestBitMask = defaultHitCategory
        addChild(table)
        
        chair.alpha = 1
        chair.position = CGPoint(x: frame.size.width / 2.45, y: 720)
        chair.zPosition = 0
        chair.physicsBody?.mass = 0
        chair.physicsBody = SKPhysicsBody(circleOfRadius: chair.size.width / 2)
        chair.physicsBody?.affectedByGravity = false
        chair.physicsBody?.isDynamic = false
        chair.physicsBody?.allowsRotation = false
        chair.physicsBody?.categoryBitMask = defaultHitCategory
        chair.physicsBody?.collisionBitMask = defaultHitCategory
        chair.physicsBody?.contactTestBitMask = defaultHitCategory
        addChild(chair)

        paper.alpha = 1
        paper.position = CGPoint(x: frame.size.width / 2.45, y: 670)
        paper.zPosition = 0
        paper.physicsBody?.mass = 0
        paper.physicsBody = SKPhysicsBody(circleOfRadius: paper.size.width / 2)
        paper.physicsBody?.affectedByGravity = false
        paper.physicsBody?.isDynamic = false
        paper.physicsBody?.allowsRotation = false
        paper.physicsBody?.categoryBitMask = defaultHitCategory
        paper.physicsBody?.collisionBitMask = defaultHitCategory
        paper.physicsBody?.contactTestBitMask = defaultHitCategory
        addChild(paper)
        
    }
    
    func student1() {
        
        stuBench.alpha = 1
        stuBench.position = CGPoint(x: frame.size.width / 2.7, y: 375)
        stuBench.zPosition = 0
        stuBench.physicsBody?.mass = 0
        stuBench.physicsBody = SKPhysicsBody(circleOfRadius: stuBench.size.width / 2)
        stuBench.physicsBody?.affectedByGravity = false
        stuBench.physicsBody?.isDynamic = false
        stuBench.physicsBody?.allowsRotation = false
        addChild(stuBench)

        stuTable.alpha = 1
        stuTable.position = CGPoint(x: frame.size.width / 2.7, y: 400)
        stuTable.zPosition = 0
        stuTable.physicsBody?.mass = 0
        stuTable.physicsBody = SKPhysicsBody(circleOfRadius: stuTable.size.width / 2)
        stuTable.physicsBody?.affectedByGravity = false
        stuTable.physicsBody?.isDynamic = false
        stuTable.physicsBody?.allowsRotation = false
        addChild(stuTable)
            
    }
    
    func student2() {
        
        stuBench2.alpha = 1
        stuBench2.position = CGPoint(x: frame.size.width / 1.47, y: 375)
        stuBench2.zPosition = 0
        stuBench2.physicsBody?.mass = 0
        stuBench2.physicsBody = SKPhysicsBody(rectangleOf: stuBench2.size)
        stuBench2.physicsBody?.affectedByGravity = false
        stuBench2.physicsBody?.isDynamic = false
        stuBench2.physicsBody?.allowsRotation = false
        addChild(stuBench2)

        stuTable2.alpha = 1
        stuTable2.position = CGPoint(x: frame.size.width / 1.47, y: 400)
        stuTable2.zPosition = 0
        stuTable2.physicsBody?.mass = 0
        stuTable2.physicsBody = SKPhysicsBody(circleOfRadius: stuTable2.size.width / 2)
        stuTable2.physicsBody?.affectedByGravity = false
        stuTable2.physicsBody?.isDynamic = false
        stuTable2.physicsBody?.allowsRotation = false
        addChild(stuTable2)
            
    }
    
    func student3() {
        
        stuBench3.alpha = 1
        stuBench3.position = CGPoint(x: frame.size.width / 2.7, y: 175)
        stuBench3.zPosition = 0
        stuBench3.physicsBody?.mass = 0
        stuBench3.physicsBody = SKPhysicsBody(circleOfRadius: stuBench3.size.width / 2)
        stuBench3.physicsBody?.affectedByGravity = false
        stuBench3.physicsBody?.isDynamic = false
        stuBench3.physicsBody?.allowsRotation = false
        addChild(stuBench3)

        stuTable3.alpha = 1
        stuTable3.position = CGPoint(x: frame.size.width / 2.7, y: 200)
        stuTable3.zPosition = 0
        stuTable3.physicsBody?.mass = 0
        stuTable3.physicsBody = SKPhysicsBody(circleOfRadius: stuTable3.size.width / 2)
        stuTable3.physicsBody?.affectedByGravity = false
        stuTable3.physicsBody?.isDynamic = false
        stuTable3.physicsBody?.allowsRotation = false
        addChild(stuTable3)
            
    }
    
    func student4() {
        
        stuBench4.alpha = 1
        stuBench4.position = CGPoint(x: frame.size.width / 1.47, y: 175)
        stuBench4.zPosition = 0
        stuBench4.physicsBody?.mass = 0
        stuBench4.physicsBody = SKPhysicsBody(circleOfRadius: stuBench4.size.width / 2)
        stuBench4.physicsBody?.affectedByGravity = false
        stuBench4.physicsBody?.isDynamic = false
        stuBench4.physicsBody?.allowsRotation = false
        addChild(stuBench4)

        stuTable4.alpha = 1
        stuTable4.position = CGPoint(x: frame.size.width / 1.47, y: 200)
        stuTable4.zPosition = 0
        stuTable4.physicsBody?.mass = 0
        stuTable4.physicsBody = SKPhysicsBody(circleOfRadius: stuTable4.size.width / 2)
        stuTable4.physicsBody?.affectedByGravity = false
        stuTable4.physicsBody?.isDynamic = false
        stuTable4.physicsBody?.allowsRotation = false
        addChild(stuTable4)
            
    }
}
