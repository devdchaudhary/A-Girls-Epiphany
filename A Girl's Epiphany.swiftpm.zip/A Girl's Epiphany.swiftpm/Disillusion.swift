//
//  Disillusion.swift
//  A Girl's Epiphany
//
// Created by Devanshu Dev Chaudhary on 07/04/22.
//

import Foundation
import SwiftUI
import SpriteKit
import Speech
import AVFoundation

class SpeechProcessor: NSObject, ObservableObject, SFSpeechRecognizerDelegate {
    
    let audioEngine = AVAudioEngine()
    var inputNode: AVAudioInputNode?
    var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    var recognitionTask: SFSpeechRecognitionTask?
    var audioSession: AVAudioSession?
    @Published var speechRecognizer: SFSpeechRecognizer?
    @Published var recognizedText: String?
    @Published var isProcessing: Bool = false
    
    func start() {
        audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession?.setCategory(.record, mode: .measurement, options: .duckOthers)
            try audioSession?.setActive(true, options: .notifyOthersOnDeactivation)
        } catch {
            print("Couldn't configure the audio session properly")
        }
        
        inputNode = audioEngine.inputNode
        speechRecognizer = SFSpeechRecognizer()
        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        speechRecognizer?.supportsOnDeviceRecognition = true
        recognitionRequest?.requiresOnDeviceRecognition = true

        guard let speechRecognizer = speechRecognizer,
        speechRecognizer.isAvailable,
        let recognitionRequest = recognitionRequest,
        let inputNode = inputNode
        else {
            print("Unable to start the speech recognition!")
            return
        }
        speechRecognizer.delegate = self
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer: AVAudioPCMBuffer, when: AVAudioTime) in
            recognitionRequest.append(buffer)
        }
        recognitionTask = speechRecognizer.recognitionTask(with: recognitionRequest) { [weak self] result, error in
            self?.recognizedText = result?.bestTranscription.formattedString
            
            guard error != nil || result?.isFinal == true else { return }
            self?.stop()
        }
        audioEngine.prepare()
        do {
            try audioEngine.start()
            isProcessing = true
        } catch {
            print("Coudn't start audio engine!")
            stop()
        }
    }
    
    func stop() {
        recognitionTask?.cancel()
        audioEngine.stop()
        inputNode?.removeTap(onBus: 0)
        try? audioSession?.setActive(false)
        audioSession = nil
        inputNode = nil
        isProcessing = false
        recognitionRequest = nil
        recognitionTask = nil
        speechRecognizer = nil
    }
    
    deinit {
    
    }
}


struct Disillusion: View {
    
    @State var affirmations = ["I am strong",
                               "I am doing my best",
                               "I am in love with myself and my body",
                               "I create a safe and secure space for myself",
                               "I will not allow others opinions of me to become my reality",
                               "I trust that I am on the right path",
                               "Congrats! \n You've Passed."]
    @State private var typedAffirmation = "Type Here"
    @State private var showButton = false
    @State private var buttonState = true
    @State var SoundEffect: AVAudioPlayer?
    @StateObject var speechProcessor = SpeechProcessor()
    @State private var didTap:Bool = false
    @State private var showTextBox = false
    @State var Script = "Having come back home Swana is sad and disturbed by the things she heard back at school. She isn't able to let go of it and the same words keep on repeating in her mind turning an uncomfortable experience into a miserable one. Not able to realise what to do in this situation she tries very hard to calm herself down and finally reaches a peaceful state of mind. Being the stubborn person that she is, she vow's to defend herself against this evil lurking in her mind and tries to make herself feel comfortable by affirming her own worthiness and value as an individual."
    @State var Script2 = "Match the given sentence with yours by either typing it in or recording your voice. If your iPad supports offline speech recognition then you will have the option to record your sentence otherwise you will be given the option to type it in - match with all 6 to move to the next level - Make sure there aren't whitespaces before and after your sentence."

    init() {
    UITextView.appearance().backgroundColor = .clear
    }
    
    func startRecording() {
        if speechProcessor.isProcessing {
            speechProcessor.stop()
        } else {
            speechProcessor.start()
        }
    }
        
    func deviceChipName() -> String {
        var deviceInfo = utsname()
        uname(&deviceInfo)
        let deviceIdentifier = withUnsafePointer(to: &deviceInfo.machine.0) { ptr in
            return String(cString: ptr)
        }
        switch deviceIdentifier {
        case"iPad11,1", "iPad11,2",
            "iPad11,3", "iPad11,4",
            "iPad11,6",  "iPad11,7":                     return "A12"
        case "iPad8,1", "iPad8,2",
            "iPad8,3", "iPad8,4":                        return "A12X"
        case "iPad8,5", "iPad8,6",
            "iPad8,7", "iPad8,8",
            "iPad8,9", "iPad8,10",
            "iPad8,11", "iPad8,12":                      return "A12Z"
        case"iPad12,1" , "iPad12,2":                     return "A13"
        case"iPad13,1", "iPad13,2" :                     return "A14"
        case"iPad14,1", "iPad14,2" :                     return "A15"
        case "iPad13,4",
            "iPad13,5",
            "iPad13,6",
            "iPad13,7",
            "iPad13,8",
            "iPad13,9",
            "iPad13,10",
            "iPad13,11":                                 return "M1"
        default:                                         return "Unknown chip"
        }
    }
        
    public var body: some View {
        NavigationView {
        ZStack {
            Color(floorColor)
                .ignoresSafeArea()
        VStack (spacing: 35) {
            
            Text(Script)
                .font(.system(size: 12, weight: .medium))
                .padding(.leading, 20)
                .padding(.trailing, 20)
                .foregroundColor(.black)
                .shadow(radius: 10)
            
            Text(Script2)
                .font(.system(size: 12, weight: .bold))
                .padding(.leading, 20)
                .padding(.trailing, 20)
                .padding(.bottom, 40)
                .foregroundColor(.black)

            ZStack {
                 RoundedRectangle(cornerRadius: 25, style: .continuous)
                    .fill(Color(carpetColor))
                    .shadow(radius: 10)
                 VStack {
                     Text(affirmations[0])
                         .font(.largeTitle)
                         .frame(width: 500, height: 100)
                         .transition(.opacity)
                         .foregroundColor(.white)
                     
                     Text(speechProcessor.recognizedText ?? "")
                         .foregroundColor(.white)
                         .padding(.bottom, 20)
                     
                     TextEditor(text: $typedAffirmation)
                         .font(.largeTitle)
                         .frame(width: 500, height: 100)
                         .foregroundColor(.white)
                         .cornerRadius(20)
                         .opacity(showTextBox ? 1:0)
                         .padding(.bottom, 10)
                                     
                NavigationLink(destination: Hope(), isActive: $showButton) {
                Button(action: {
                    switch deviceChipName().description {
                    case "A12":
                        startRecording()
                    case "A12X":
                        startRecording()
                    case "A12Z":
                        startRecording()
                    case "A13":
                        startRecording()
                    case "A14":
                        startRecording()
                    case "A15":
                        startRecording()
                    case "M1":
                        startRecording()
                    default:
                        showTextBox.toggle()
                    }
                    buttonState.toggle()
                    for var i in 0..<affirmations.count {
                    i = i+1
                    for j in 0..<affirmations.count {
                    if speechProcessor.recognizedText == affirmations[j] || typedAffirmation == affirmations[j] {
                    withAnimation (.easeInOut(duration: 1)) {
                    AudioServicesPlaySystemSound(1004)
                    affirmations[j] = affirmations[j+1]
                    }}}}}, label: {
                    Text((affirmations[0] == affirmations[6] ) ? "Continue" : "Record/Check")
                    .font(.largeTitle)
                    .frame(width: 500, height: 100)
                    .foregroundColor(.white)
                    .cornerRadius(20)
                    .padding(.bottom, 10)
                    })
                    .foregroundColor(.white)
                    .font(.system(size: 40, weight: .regular))
                  }
                .simultaneousGesture(TapGesture().onEnded{
                if affirmations[0] == affirmations[6] {
                showButton.toggle()
                }})
                }
                .padding(20)
                .multilineTextAlignment(.center)
             }
            .frame(width: 400, height: 300)
        }
        .statusBar(hidden: true)
        }
        .onAppear {
            print(deviceChipName().description)
        }
    }
        .navigationViewStyle(StackNavigationViewStyle())
        .navigationBarHidden(true)
        .navigationBarBackButtonHidden(true)
    }
}

